package edu.cs3500.spreadsheets.provider;

/**
 * Formula class created so that the interface wouldn't output errors. Assume that this is a class
 * used in the evaluation, but we didn't need it so we didn't implement anything here.
 */
public class Formula {
}
