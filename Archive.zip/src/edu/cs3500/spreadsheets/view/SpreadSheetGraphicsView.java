package edu.cs3500.spreadsheets.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.util.List;
import java.util.function.Consumer;

import javax.swing.JFrame;
import javax.swing.JScrollBar;
import javax.swing.JOptionPane;

import edu.cs3500.spreadsheets.model.IWorkSheet;


/**
 * Graphical view for spreadsheet.
 */

public class SpreadSheetGraphicsView extends JFrame implements IView {
  // Consumer, accepts a string and performs an operation onit
  Consumer<String> commandCallback;

  /**
   * Constructor for Graphical view.
   * @param inputWs Worksheet
   */

  public SpreadSheetGraphicsView(IWorkSheet inputWs) {
    super();
    IWorkSheet ws = inputWs;
    List<List<String>> data = ws.getProcessedDataSheet();

    this.setTitle("Spreadsheet");
    this.setSize(1002, 502);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //look into the different layouts
    this.setLayout(new BorderLayout());

    SpreadSheetPanel spreadSheetPanel = new SpreadSheetPanel(data);

    //Scoll bars
    JScrollBar horizontal = new JScrollBar(JScrollBar.HORIZONTAL);
    JScrollBar vertical = new JScrollBar(JScrollBar.VERTICAL, 0, 20, 0, 500);

    SpreadSheetScrollPanel scroll = new SpreadSheetScrollPanel(spreadSheetPanel,
            horizontal, vertical);
    this.add(scroll, BorderLayout.CENTER);
    scroll.setPreferredSize(new Dimension(1002, 502));

    class HorizontalScrollListener implements AdjustmentListener {
      public void adjustmentValueChanged(AdjustmentEvent e) {
        scroll.horizontalScroll(e.getValue());
        scroll.repaint();
      }
    }

    class VerticalScrollListener implements AdjustmentListener {
      public void adjustmentValueChanged(AdjustmentEvent e) {
        scroll.verticalScroll(e.getValue());
        scroll.repaint();
      }
    }

    horizontal.addAdjustmentListener(new HorizontalScrollListener( ));
    vertical.addAdjustmentListener(new VerticalScrollListener( ));


    this.add(vertical, BorderLayout.EAST);
    this.add(horizontal, BorderLayout.SOUTH);


    commandCallback = null;

    this.pack();
  }

  @Override
  public void makeVisible() {
    this.setVisible(true);
  }

  @Override
  public void setCommandCallback(Consumer<String> callback) {
    //Nothing happening here
  }

  @Override
  public void refresh() {
    this.repaint();
  }

  @Override
  public void showErrorMessage(String error) {
    JOptionPane.showMessageDialog(this, error, "Error", JOptionPane.ERROR_MESSAGE);

  }
}
