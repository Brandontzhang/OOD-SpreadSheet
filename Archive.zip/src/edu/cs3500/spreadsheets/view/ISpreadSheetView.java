package edu.cs3500.spreadsheets.view;

import java.io.IOException;

/**
 * Interface for SpreadSheetView.
 */

public interface ISpreadSheetView {
  void render() throws IOException;
}